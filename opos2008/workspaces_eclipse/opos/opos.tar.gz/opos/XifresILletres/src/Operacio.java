
public class Operacio {
	
	/*
	
	public static final String SUMA="+";
	
	public static final String RESTA="-";
	
	public static final String MULTIPLICACIO="*";
	
	public static final String DIVISIO="/";
	
	private String operand1;
	
	private String operand2;
	
	private String operacio;
	
	public Operacio() {
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String toString() {
		
		
		return super.toString();
	}
	
	boolean operacioValida(){
		if (this.getOperacio().equals(this.DIVISIO) ) {
			/*if (this.getOperand2()%this.getOperand2()!=0) {
				return false;
			}
		}
		//La resta comprovar que el resultat esta entre 0 i 999
		
		return true;
	}

	public String getOperand1() {
		return operand1;
	}

	public void setOperand1(String operand1) {
		this.operand1 = operand1;
	}

	public String getOperand2() {
		return operand2;
	}

	public void setOperand2(String operand2) {
		this.operand2 = operand2;
	}

	public String getOperacio() {
		return operacio;
	}

	public void setOperacio(String operacio) {
		this.operacio = operacio;
	}*/

}
