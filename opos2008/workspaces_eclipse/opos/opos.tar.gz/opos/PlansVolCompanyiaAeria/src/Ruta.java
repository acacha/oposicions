
public class Ruta {
	
	public String origen;
	
	public String destinacio;

}
